import java.util.Scanner;

public class Ejercicio_09_relacion02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n;
		
			System.out.println("Introduce un numero: ");
			n=sc.nextInt();
			int digitos = 0;
			
			
		while(n!=0) {
			n=n/10;
			digitos++;
			
				}
		System.out.println("El numero tiene: "+digitos) ;
			}
	}







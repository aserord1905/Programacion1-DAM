
public class Ejercicio_04_relacion_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		for(int i=320; i>=160; i=i-20)
		{
		System.out.println(i);
		
		}	
	}
}



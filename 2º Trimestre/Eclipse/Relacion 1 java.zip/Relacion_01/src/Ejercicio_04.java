
import java.util.Scanner;
public class Ejercicio_04 {
	public static void main(String[] Args) {
		Scanner t=new Scanner(System.in);
		
		double valorPeseta=166.386;
		double cantidad,resultadoEuro;
				
		
		System.out.println("Cantidad en pesetas:");
		cantidad=t.nextDouble();
		
		resultadoEuro=cantidad / valorPeseta;
		
		System.out.println("Valor en Euro: " +resultadoEuro);
		
}
}
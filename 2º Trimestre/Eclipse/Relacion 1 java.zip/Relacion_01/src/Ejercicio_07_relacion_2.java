import java.util.Scanner;
public class Ejercicio_07_relacion_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner t=new Scanner(System.in);
		
		
		int passwordCondition=1;
		int digitosContrasena=0;
		
		while (digitosContrasena!=1234 && passwordCondition<5);
		System.out.println("Pon la contrase�a: ");
		digitosContrasena=t.nextInt();
		if (digitosContrasena!=1234) {
			passwordCondition++;
			
		}else {
			System.out.println("Es correcta la combinacion ");
		}
		
	}

}

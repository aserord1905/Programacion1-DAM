import javax.swing.JOptionPane;
public class Ejercicio_03_relacion_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=0;
		do {
			System.out.println(n);
			n=n+5;
			
		}while(n<101);
	}

}

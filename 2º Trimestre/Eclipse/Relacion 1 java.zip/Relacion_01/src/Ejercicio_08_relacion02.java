import java.util.Scanner;

public class Ejercicio_08_relacion02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	        int n;
	        System.out.print("Introduce un n�mero entero: ");                                                         
	        n = sc.nextInt();
	        System.out.println("Tabla del " + n);
	        for(int i = 1; i<=10; i++){
	             System.out.println(n*i);                                                     
	        }
	}

}

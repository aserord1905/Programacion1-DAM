
public class Ejercicio_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre="Alejandro Serrano Ord��ez";
		String direccion="Avenidad Antonio Mairena";
		String telefono="698253645";
		System.out.println("Mi nombre completo es " +nombre);
		System.out.println("Mi direccion es " +direccion);
		System.out.println("Mi telefono es " +telefono);
}
}
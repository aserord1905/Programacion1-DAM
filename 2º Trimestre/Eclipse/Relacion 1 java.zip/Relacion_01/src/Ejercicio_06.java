import java.util.Scanner;

public class Ejercicio_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner t=new Scanner(System.in);
		double cantidad;
		double BaseImponible=1.21;
		double resultadoBaseImponible;
		System.out.println("Valor total del sueldo:");
		cantidad=t.nextDouble();
		resultadoBaseImponible=cantidad/BaseImponible;
		System.out.println("La base Imponible vale: "+resultadoBaseImponible);
		
		
	}

}

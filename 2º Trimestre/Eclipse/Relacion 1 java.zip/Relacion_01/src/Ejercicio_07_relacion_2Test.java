import static org.junit.Assert.*;

import org.junit.Test;

public class Ejercicio_07_relacion_2Test {

	@Test
	public void testMain() {
		fail("Not yet implemented");
	}

}

import java.util.Scanner;

public class Ejercicio_10_relacion02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	int n=1;
	int suma=0;
	int contador=0;
			while(n>0) {
				System.out.println("Escribe un numero: ");
				  n=sc.nextInt();
				  if(n>0) {
					  suma=suma+n;
					  contador++;
				  }
					//System.out.println("suma" +suma+ "contador"+contador);
				  
				  
				  
			}
			
			System.out.println("La media de los numeros introducidos es:" +suma/contador);
			
	

	}
}
		

	



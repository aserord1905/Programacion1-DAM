
public class Ejercicio_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=144;
		int y=999;
		int suma=0;
		int division=0;
		int resta=0;
		int multiplicacion=0;
		System.out.println("Las variables son: " +x +" y "+y);
		suma= x+y;
		multiplicacion=x*y;
		division=x/y;
		resta=x-y;
		System.out.println("La suma de los numeros son: "+suma);
		System.out.println("La resta de los numeros son: "+resta);
		System.out.println("La multiplicacion de los numeros son: "+multiplicacion);
		System.out.println("La division de los numeros es: " +division);
			}

}

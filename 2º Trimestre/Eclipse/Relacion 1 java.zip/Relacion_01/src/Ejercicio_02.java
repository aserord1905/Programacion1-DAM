
public class Ejercicio_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombre="Alejandro Serrano Ord��ez";
		System.out.println("Mi nombre completo es " +nombre);
}
}

public class Ejercicio_06_relacion2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=320;
		do {
			System.out.println(n);
			n=n-20;
		}while (n>161);
	}

}

import java.util.Scanner;

public class Ejercicio_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner t=new Scanner(System.in);
		double valorPeseta=166.386;
		double cantidad,resultadoPeseta;
		System.out.println("Cantidad en euros:");
		cantidad=t.nextDouble();
		resultadoPeseta=cantidad * valorPeseta;
		System.out.println("Valor en Pesetas: " +resultadoPeseta);
	}

}

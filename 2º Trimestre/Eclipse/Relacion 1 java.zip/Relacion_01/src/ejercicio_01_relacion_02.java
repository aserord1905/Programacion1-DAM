
//Muestra los n�meros m�ltiplos de 5 de 0 a 100 utilizando un bucle for
import java.util.Scanner;

public class ejercicio_01_relacion_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=0; i<=100; i=i+5)
		{
		System.out.println(i);
		
		}	
	}
}

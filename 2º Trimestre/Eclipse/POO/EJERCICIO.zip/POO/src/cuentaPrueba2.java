
public class cuentaPrueba2 {

	public static void main(String[] args) {
		cuenta micuenta=new cuenta(null, null, 0, 0);
		micuenta.Cuenta2();
	}

}

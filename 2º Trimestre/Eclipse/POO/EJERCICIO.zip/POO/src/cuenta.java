
public class cuenta {
	private String nombre_cliente;
	private String numero_cuenta;
	private double tipo_interes;
	private double saldo;
	
	public cuenta(String nombre_cliente, String numero_cuenta, double tipo_interes, double saldo) {
		super();
		this.nombre_cliente = nombre_cliente;
		this.numero_cuenta = numero_cuenta;
		this.tipo_interes = tipo_interes;
		this.saldo = saldo;
	}
	

	
	public String getNombre_cliente() {
		return nombre_cliente;
	}



	public void setNombre_cliente(String nombre_cliente) {
		this.nombre_cliente = nombre_cliente;
	}



	public String getNumero_cuenta() {
		return numero_cuenta;
	}



	public void setNumero_cuenta(String numero_cuenta) {
		this.numero_cuenta = numero_cuenta;
	}



	public double getTipo_interes() {
		return tipo_interes;
	}



	public void setTipo_interes(double tipo_interes) {
		this.tipo_interes = tipo_interes;
	}



	public double getSaldo() {
		return saldo;
	}



	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}



	public void Cuenta1() {
		
	}
	
	public void Cuenta2() {
		this.nombre_cliente="Juan Fernandez Rubio";
		this.numero_cuenta="1234567890";
		this.tipo_interes=1.75;
		this.saldo=300;
		
	}
	
	//metodo ingreso.
	 public boolean ingreso(double n) {
	        boolean ingresoCorrecto = true;
	        if (n < 0) {
	            ingresoCorrecto = false;
	        } else {
	            saldo = saldo + n;
	        }
	        
	        return ingresoCorrecto;
	        
	    }

	 
	 //metodo de transferencia.
	 
}

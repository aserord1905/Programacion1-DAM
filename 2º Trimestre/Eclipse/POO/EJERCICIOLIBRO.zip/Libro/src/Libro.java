
public class Libro {
	private String titulo;
	private String autor;
	private int numero_ejemplares;
	private int numero_ejemplares_prestados;
	
	public Libro() {
		
	}

	public Libro(String titulo, String autor, int numero_ejemplares, int numero_ejemplares_prestados) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.numero_ejemplares = numero_ejemplares;
		this.numero_ejemplares_prestados = numero_ejemplares_prestados;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public int getNumero_ejemplares() {
		return numero_ejemplares;
	}

	public void setNumero_ejemplares(int numero_ejemplares) {
		this.numero_ejemplares = numero_ejemplares;
	}

	public int getNumero_ejemplares_prestados() {
		return numero_ejemplares_prestados;
	}

	public void setNumero_ejemplares_prestados(int numero_ejemplares_prestados) {
		this.numero_ejemplares_prestados = numero_ejemplares_prestados;
	}

	  public boolean prestamo() {
	        boolean prestado = true;
	        if (numero_ejemplares_prestados < numero_ejemplares) {
	            numero_ejemplares_prestados++;
	        } else {
	            prestado = false;
	        }
	        return prestado;
	    }
	
	  public boolean devolucion() {
		  boolean devuelto = true;
	        int prestados = 0;
			if (prestados == 0) {
	            devuelto = false;
	        } else {
	            prestados--;
	        }
	        return devuelto;
	    }
	  }



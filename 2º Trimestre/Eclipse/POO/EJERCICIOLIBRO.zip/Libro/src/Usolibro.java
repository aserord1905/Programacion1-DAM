import java.util.Scanner;

public class Usolibro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 	Scanner sc = new Scanner(System.in);
	        String titulo, autor;
	        int ejemplares;
	        
	        Libro libro1 = new Libro("El quijote", "Cervantes", 1, 0);
	        
	        Libro libro2 = new Libro();
	        
	        System.out.print("Introduce titulo: ");
	        titulo = sc.nextLine();
	        System.out.print("Introduce autor: ");
	        autor = sc.nextLine();
	        System.out.print("Numero de ejemplares: ");
	        ejemplares = sc.nextInt();
	        
	        
	        libro2.setTitulo(titulo);
	        libro2.setAutor(autor);
	        libro2.setNumero_ejemplares(ejemplares);
	        
	        
	        System.out.println("Libro 1:");
	        System.out.println("Titulo del libro: " + libro1.getTitulo());
	        System.out.println("Autor: " + libro1.getAutor());
	        System.out.println("Ejemplares: " + libro1.getNumero_ejemplares());
	        System.out.println("Prestados: " + libro1.getNumero_ejemplares_prestados());
	        System.out.println();
	        
	        
	        System.out.println("Libro 2: ");
	        System.out.println("Titulo: " + libro2.getTitulo());
	        System.out.println("Autor: " + libro2.getAutor());
	        System.out.println("Ejemplares: " + libro2.getNumero_ejemplares());
	        System.out.println("Prestados: " + libro2.getNumero_ejemplares_prestados());
	        

	}

}

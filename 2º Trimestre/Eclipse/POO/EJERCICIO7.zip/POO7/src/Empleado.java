
public class Empleado {
private String nif;
private String nombre;
private double sueldo_base;
private int horas_extras;
private double irpf;
private char casado;
private int numero_hijos;
private static double importeHora;
public Empleado(String nif) {
	super();
	this.nif = nif;
}

public String getNif() {
	return nif;
}

public void setNif(String nif) {
	this.nif = nif;
}

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}
public double getSueldo_base() {
	return sueldo_base;
}
public void setSueldo_base(double sueldo_base) {
	this.sueldo_base = sueldo_base;
}
public int getHoras_extras() {
	return horas_extras;
}
public void setHoras_extras(int horas_extras) {
	this.horas_extras = horas_extras;
}
public double getIrpf() {
	return irpf;
}
public void setIrpf(double irpf) {
	this.irpf = irpf;
}
public char isCasado() {
	return casado;
}
public void setCasado(char casado) {
	this.casado = casado;
}
public int getNumero_hijos() {
	return numero_hijos;
}
public void setNumero_hijos(int numero_hijos) {
	this.numero_hijos = numero_hijos;
}
public static double getImporteHora() {
	return importeHora;
}
public static void setImporteHora(double importeHora) {
	Empleado.importeHora = importeHora;
}

public double ImporteHorasExtras() {
	return horas_extras*importeHora;
}

public double salarioBruto() {
	return sueldo_base+ImporteHorasExtras();
}

public double calculoIrpf() {
	
	if(casado=='s' || casado=='S' && numero_hijos>0) {
		return ((irpf-2-numero_hijos)*salarioBruto())/100;
	}else if(casado!='s' || casado!='S' && numero_hijos>0) {
		return ((irpf-2-numero_hijos)*salarioBruto())/100;
	}else if(numero_hijos<0) {
		return numero_hijos=0;
	}else if(casado=='s' || casado=='S' && numero_hijos==0) {
		return ((irpf-2)*salarioBruto())/100;
	}
	
	
	return (irpf*salarioBruto())/100;
	
	
}

@Override
public String toString() {
	return "Empleado [nif=" + nif + ", nombre=" + nombre + ", sueldo_base=" + sueldo_base + ", horas_extras="
			+ horas_extras + ", irpf=" + irpf + ", casado=" + casado + ", numero_hijos=" + numero_hijos + "]";
}



}

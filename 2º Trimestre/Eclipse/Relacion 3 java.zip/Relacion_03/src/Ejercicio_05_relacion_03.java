
public class Ejercicio_05_relacion_03 {

	public static void main(String[] args) {
		int numAleatorio=0;
		int i=0;
		int suma=0;
		for( i=1; i<=5;i++) {
			  numAleatorio=((int)(Math.random()*100 + 100));
			
			System.out.println("Tirada: "+numAleatorio);
			  suma=suma+numAleatorio;
				
		
			
		}
		System.out.println("La suma es: " +suma);
			 
		  
	}

}

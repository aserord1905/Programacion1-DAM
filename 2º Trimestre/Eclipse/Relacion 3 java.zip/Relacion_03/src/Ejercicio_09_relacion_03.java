
public class Ejercicio_09_relacion_03 {

	public static void main(String[] args) {
		int numAleatorio=0;
		int i=0;
		int contadorsuspenso=0;
		int contadorsuficiente=0;
		int contadorbien=0;
		int contadornotable=0;
		int contadorsobresaliente=0;
		for( i=1; i<=20;i++) {
			  numAleatorio=((int)(Math.random()*10 + 0));
			
			System.out.println("Nota: "+numAleatorio);
			if(numAleatorio<5) {
				contadorsuspenso++;
			}
			if(numAleatorio==6) {
				contadorbien++;
			}
			if(numAleatorio>=7 && numAleatorio<=8) {
				contadornotable++;
			}
			if(numAleatorio>8) {
				contadorsobresaliente++;
			}
		}
		System.out.println("N� sobresalientes: " +contadorsobresaliente);
		System.out.println("N� notables: " +contadornotable);
		System.out.println("N� bien: " +contadorbien);
		System.out.println("N� suficientes: " +contadorsuficiente);
		System.out.println("N� suspensos: " +contadorsuspenso);
	
	}

}


public class Ejercicio_01_Relacion_03 {

	

	public static void main(String[] args) {
		System.out.println("Numero aleatorio entre 1 y 6");
		int numAleatorio=0;
		int numAleatorio1=0;
		int numAleatorio2=0;
		for(int i=1; i<=1;i++) {
			  numAleatorio=((int)(Math.random()*6 + 1));
			System.out.println("Dado 1: "+numAleatorio);
		}
		
		for(int i=1; i<=1;i++) {
			  numAleatorio1=((int)(Math.random()*6 + 1));
			System.out.println("Dado 2: "+numAleatorio1);
	}
		for(int i=1; i<=1;i++) {
			  numAleatorio2=((int)(Math.random()*6 + 1));
			System.out.println("Dado 3: "+numAleatorio2);
	}
	 int suma= (numAleatorio + numAleatorio1 + numAleatorio2);
		System.out.println("La suma de los dados es: "+suma);
}
}

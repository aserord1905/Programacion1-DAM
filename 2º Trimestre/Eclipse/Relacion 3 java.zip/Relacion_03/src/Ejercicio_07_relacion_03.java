
public class Ejercicio_07_relacion_03 {

	public static void main(String[] args) {
		int numAleatorio=0;
		int i=0;
		int suma=0;
		int contador=0;
		
			while(numAleatorio!=24) {
			  numAleatorio=((int)(Math.random()*100 + 0));
			
			System.out.println("Numero Aleatorio: "+numAleatorio);
			contador++;
			}
				
		System.out.println("Se ha generado: " +contador);
			
		
	}

}

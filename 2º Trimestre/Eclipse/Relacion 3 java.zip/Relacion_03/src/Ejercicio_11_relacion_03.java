
public class Ejercicio_11_relacion_03 {

	public static void main(String[] args) {
		int numAleatorio=0;
		int numAleatorio1=0;
		
			  
			numAleatorio=((int)(Math.random()*6 + 1));
			System.out.println("Dado 1: "+numAleatorio);
		
		
		
			  numAleatorio1=((int)(Math.random()*6 + 1));
			System.out.println("Dado 2: "+numAleatorio1);
	
			while(numAleatorio!=numAleatorio1) {
				  
				numAleatorio=((int)(Math.random()*6 + 1));
				System.out.println("Dado 1: "+numAleatorio);
			
			
			
				  numAleatorio1=((int)(Math.random()*6 + 1));
				System.out.println("Dado 2: "+numAleatorio1);
		
		}

}
}
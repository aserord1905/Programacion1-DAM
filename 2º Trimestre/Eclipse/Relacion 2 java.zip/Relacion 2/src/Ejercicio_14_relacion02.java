import java.util.Scanner;

public class Ejercicio_14_relacion02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner sc = new Scanner(System.in);
		double result;
		 System.out.println("Introduce la base: ");
		 int n=sc.nextInt();
		 System.out.println("Introduce un exponente: ");
		 int n1=sc.nextInt();
		 if(n1<0) {
			 System.out.println("Introduce de nuevo un exponente: ");
			 int n11=sc.nextInt();
		 }
		 	result = Math.pow(n,n1);
		 System.out.println("El resultado de la potencia introducida es: " + result);

	
	}
}

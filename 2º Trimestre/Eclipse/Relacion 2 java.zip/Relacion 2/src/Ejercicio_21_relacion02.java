import java.util.Scanner;

public class Ejercicio_21_relacion02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	int n=1;
	int sumapares=0;
	int contadorpares=0;
	int sumaimpares=0;
	int contadorimpares=0;
			while(n>0) {
				System.out.println("Escribe un numero: ");
				  n=sc.nextInt();
				  if(n>0) {
				  if(n % 2==0) {
					  sumapares=sumapares+n;
					  contadorpares++;
				  }
					System.out.println("suma " +sumapares+ " contador "+contadorpares);
				  
				  if(n % 2 != 0) {
					  sumaimpares=sumaimpares+n;
					  contadorimpares++;
				  }
				  
			}
			}
			
			System.out.println("La media de los numeros pares introducidos es:" +sumapares/contadorpares);
			System.out.println("La media de los numeros impares introducidos es:" +sumaimpares/contadorimpares);
			
	

	}
}

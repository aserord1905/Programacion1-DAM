import java.util.Scanner;

public class Ejercicio_25_relacion02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("Escribe un numero: ");
		  n=sc.nextInt();
		  for(int i=n; i <= n; i=i-1) {
			  System.out.println(n);
		  }

	}

}

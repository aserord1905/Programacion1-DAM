import java.util.Scanner;

public class Ejercicio_13_relacion_02 {
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 int contadorpos=0;
		 int contadorneg=0;
		
		 
		 for(int i=1;i<=10; i=i+1) {
			 System.out.println("Introduce un numero: ");
			 int n=sc.nextInt();
			 
		 }
		 
		 int n;
		 if (n<0) {
			 System.out.println("El numero que has introducido es negativo: " + n);
		 contadorneg++;
		 }
		
		 if(n>0) {
			 System.out.println("El numero que has introducido es positivo: " + n);
		 contadorpos++;
		 }
		 System.out.println("Los numeros positivos totales son:" + contadorpos);
		 System.out.println("Los numeros negativos totales son:" + contadorneg);
		 
		 sc.close();
		 
	}
	}		
	
		
import java.util.Scanner;

public class Ejercicio_18_relacion_02 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un primer numero: ");
		 int n=sc.nextInt();
		 
		 System.out.println("Introduce un segundo numero: ");
		 int n2=sc.nextInt();
		 
		 for(int i=n; i <= n2; i=i+7) {
			 System.out.println(i);
			 
		 }
		
	}
}

import java.util.Scanner;

public class Ejercicio_16_relacion02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		 System.out.println("Introduce un numero: ");
		 int n=sc.nextInt();
		 
		 for(i=2; i<=n; i = i+1) {
			 
		 }
	}

}

import java.util.Scanner;

public class Ejercicio_17_Relacion_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		 System.out.println("Introduce un numero: ");
		 int n=sc.nextInt();
		 
		 for( int i = n ; i<=n+100; i=i+1) {
			int suma=n+i;
			System.out.println(+ suma);
			 
		 }
		
	}

}

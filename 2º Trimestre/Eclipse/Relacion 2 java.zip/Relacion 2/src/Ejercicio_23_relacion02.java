import java.util.Scanner;

public class Ejercicio_23_relacion02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=1;
		int suma=0;
		int contadornum=0;
		
		while(suma<10000) {
			if(n<10000) {
			System.out.println("Escribe un numero: ");
			  n=sc.nextInt();
			  contadornum++;
			  suma=suma+n;
		}
			if(suma>10000) {
				suma=suma-n;
				
			}
			System.out.println("La suma es: " +suma);
			System.out.println("Contador: " +contadornum);
			System.out.println("Media: " +suma/contadornum);

	}

}
}
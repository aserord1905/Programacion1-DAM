import java.util.Scanner;

public class Ejercicio_28_relacion02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n=0;
		
		System.out.println("Escribe un numero: ");
		  n=sc.nextInt();
		  
		  for(int i=1; i<=n; i=i+1) {
			  System.out.println("El factorial es: " +n*i);
		  }

	}

}

import java.util.Scanner;

public class Ejercicio_13relacion02 {

	public static void main(String[] args) {
		int contadorneg=0; 
		int contadorpos=0;
		Scanner sc = new Scanner(System.in);
		for(int i=1; i <= 10; i=i+1) {
			 
			 System.out.println("Escribe un numero: ");
			 int n=sc.nextInt();
		 
		
		if(n<0) {
			System.out.println("El numero que has introducido es negativo");
			contadorneg++;
		}
		
		if(n>=0) {
			System.out.println("El numero que has introducido es positivo");
			contadorpos++;
			
			
		} 
		System.out.println("La cantidad total de numeros positivos son: "  +contadorpos);
		System.out.println("La cantidad total de numeros negativos son: "  +contadorneg);
	}
		
	}
	}
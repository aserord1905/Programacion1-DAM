import java.util.Scanner;

public class Ejercicio_27_relacion02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n;
		int contador=0;
		int suma=0;
		System.out.println("Escribe un numero: ");
		  n=sc.nextInt();
		  for(int i=1; i<=n; i=i+1) {
			  if(i % 3==0) {
				  System.out.println(i);
				  contador++;
				  suma=suma+i;
				  
			  }
			  
		  }
		  System.out.println("Contador: " +contador);
		  System.out.println("Suma: " +suma);
	}

}

import java.util.Scanner;

public class Ejercicio_11_relacion02 {
		public static void main(String[] args) {
			
		
		Scanner sc = new Scanner(System.in);
		int numero=0;
		int cuadrado=0;
		 System.out.println("Introduce un numero: ");
		 int n=sc.nextInt();
		for(int i=numero; i<=numero+5;i++) {
			numero=numero*numero;
			System.out.println("El numero al cuadrado es: " +numero);
		}
	
		}
}
